class Producto:
    def __init__(self, codigoProducto, nombreProducto, descripcionProducto, precioUnitario):
        self.codigoProducto = codigoProducto
        self.nombreProducto = nombreProducto
        self.descripcionProducto = descripcionProducto
        self.precioUnitario = precioUnitario  
